from os import system

print("Tic Tac Toe by Kevin Lutz")
gameGrid = ["1", "2", "3", "4", "5", "6", "7", "8", "9"]

turn = 'x'

while True:
    system('cls')
    print('\n', 
    gameGrid[0], '|', gameGrid[1], '|', gameGrid[2], '\n',
    '---------\n',
    gameGrid[3], '|', gameGrid[4], '|', gameGrid[5], '\n',
    '---------\n',
    gameGrid[6], '|', gameGrid[7], '|', gameGrid[8], '\n')

    if (gameGrid[0] == gameGrid[1] and gameGrid[1] == gameGrid[2]) or (gameGrid[0] == gameGrid[3] and gameGrid[3] == gameGrid[6]) or (gameGrid[0] == gameGrid[4] and gameGrid[4] == gameGrid[8]) or (gameGrid[1] == gameGrid[4] and gameGrid[4] == gameGrid[7]) or (gameGrid[2] == gameGrid[4] and gameGrid[4] == gameGrid[6]) or (gameGrid[2] == gameGrid[5] and gameGrid[5] == gameGrid[8]) or (gameGrid[3] == gameGrid[4] and gameGrid[4] == gameGrid[5]) or (gameGrid[6] == gameGrid[7] and gameGrid[7] == gameGrid[8]):
        if turn == 'o':
            print('x wins!')
            input('Press enter to exit...')
            break
        else:
            print('o wins!')
            input('Press enter to exit...')
            break

    space = int(input('Enter a number: '))
    if gameGrid[space-1] == 'x' or gameGrid[space-1] == 'o':
        print('Space occupupied.')
        continue
    if turn == 'x':
        gameGrid[space-1] = 'x'
        turn = 'o'
    elif turn == 'o':
        gameGrid[space-1] = 'o'
        turn = 'x'