import random
from time import sleep

print("Blackjack Game by Kevin Lutz")

suits = ["♥", "♦", "♣", "♠"]
values = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]

cards = []
dealerHand = []
playerHand = []
deckSize = 51

def calcCardValue(card):
    return {
        "2": 2,
        "3": 3,
        "4": 4,
        "5": 5,
        "6": 6,
        "7": 7,
        "8": 8,
        "9": 9,
        "1": 10,
        "J": 10,
        "Q": 10,
        "K": 10,
        "A": 11,
    }[card]

def calcHandValue(hand):
    sum = 0
    aceCount = 0

    for i in range(0, len(hand)):
        if calcCardValue(hand[i][0]) == 11:
            aceCount += 1
        sum += calcCardValue(hand[i][0])

    if sum > 21 and aceCount >= 1:
        sum -= 10
    return sum

def hitMe(deckSize):
    playerHand.append(cards[random.randint(0,deckSize)])
    deckSize -= 1
    cards.remove(playerHand[len(playerHand)-1])

    if calcHandValue(playerHand) == 21:
        displayHandsAndValues()
        print("You have Blacjack! You win!")
        sleep(10)
        quit()
    if calcHandValue(playerHand) > 21:
        displayHandsAndValues()
        print("You bust! You lose!")
        sleep(10)
        quit()
    else:
        displayGame()

def hitDealer(deckSize):
    print("Dealer hits.")

    dealerHand.append(cards[random.randint(0,deckSize)])
    deckSize -= 1
    cards.remove(dealerHand[len(dealerHand)-1])

    if calcHandValue(dealerHand) <= 16:
        hitDealer(deckSize)
    if calcHandValue(dealerHand) > 21:
        displayHandsAndValues()
        print("Dealer busts! You win!")
        sleep(10)
        quit()
    print("Dealer's Hand:", dealerHand)

def displayHandsAndValues():
    print("\n\nDealer's Hand:", dealerHand)
    print("Dealer's Hand Value:", calcHandValue(dealerHand))
    print("Your Hand:", playerHand)
    print("Your Hand Value:", calcHandValue(playerHand))

def displayGame():
    print("\n\nDealer's Hand:", dealerHand[0], "?")
    print("Your Hand:", playerHand)
    print("Your Hand Value:", calcHandValue(playerHand))
    print("---------------------")
    choice = input("Hit or stay? ")

    if choice.lower() == "stay":
        if calcHandValue(playerHand) == 21:
            print("You have Blackjack! You win!")
            sleep(10)
            quit()
        print("Dealer's Hand:", dealerHand)
        if calcHandValue(playerHand) > 21:
            print("You bust! You lose!")
        if calcHandValue(dealerHand) <= 16:
            hitDealer(deckSize)
        if calcHandValue(dealerHand) == 21:
            print("Dealer has Blackjack. You lose.")
            sleep(10)
            quit()
        else:
            if calcHandValue(playerHand) > calcHandValue(dealerHand):
                displayHandsAndValues()
                print("You win!")
                sleep(10)
                quit()
            elif calcHandValue(playerHand) < calcHandValue(dealerHand):
                displayHandsAndValues()
                print("You lose!")
                sleep(10)
                quit()
            else:
                displayHandsAndValues()
                print("It's a tie!")
                sleep(10)
                quit()
    
    if choice.lower() == "hit":
        hitMe(deckSize)

for m in range(0,52):
    cards.append(None)

for i in range(0,4):
    for j in range(0, 13):
        if i == 0:
            cards[j] = (values[j] + suits[i])
        elif i == 1:
            cards[j+13] = (values[j] + suits[i])
        elif i == 2:
            cards[j+26] = (values[j] + suits[i])
        elif i == 3:
            cards[j+39] = (values[j] + suits[i])

dealerHand.append(cards[random.randint(0,deckSize)])
deckSize -= 1
cards.remove(dealerHand[0])
dealerHand.append(cards[random.randint(0,deckSize)])
deckSize -= 1
cards.remove(dealerHand[1])

playerHand.append(cards[random.randint(0,deckSize)])
deckSize -= 1
cards.remove(playerHand[0])
playerHand.append(cards[random.randint(0,deckSize)])
deckSize -= 1
cards.remove(playerHand[1])

displayGame()